<h1>New Invoice Created!</h1>
<p>You have a new invoice for the amount of <?=_money_format($invoice_amount['total'])?> on the <?=$project_name?> project.<br></p>
Check it out: <a href="<?=base_url()?>"><?=base_url()?></a>