<h1>New Project</h1>
Your new project (<?=$project_name?>) has been created!<br>
Check it out: <a href="<?=base_url()?>"><?=base_url()?></a>