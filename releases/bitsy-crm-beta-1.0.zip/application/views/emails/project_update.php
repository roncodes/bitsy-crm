<h1>Update on Project</h1>
The project facilitators have made an update on your project (<?=$project_title?>)<br>
Check it out: <a href="<?=base_url()?>"><?=base_url()?></a>