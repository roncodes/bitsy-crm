<h2>Payment Canceled!</h2>

<p>The order was canceled...</p>