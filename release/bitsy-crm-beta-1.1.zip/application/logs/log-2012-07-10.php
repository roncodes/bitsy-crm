<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-07-10 01:02:13 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\bitsy-crm\application\controllers\ajax.php 31
ERROR - 2012-07-10 01:02:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\bitsy-crm\application\controllers\ajax.php 31
ERROR - 2012-07-10 01:04:17 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\bitsy-crm\application\controllers\ajax.php 31
ERROR - 2012-07-10 01:04:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\bitsy-crm\application\controllers\ajax.php 31
ERROR - 2012-07-10 01:04:33 --> Severity: Notice  --> Undefined index: recurring C:\wamp\www\bitsy-crm\application\models\core.php 73
ERROR - 2012-07-10 01:07:54 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\bitsy-crm\application\controllers\ajax.php 31
ERROR - 2012-07-10 01:07:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\bitsy-crm\application\controllers\ajax.php 31
ERROR - 2012-07-10 01:08:34 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\bitsy-crm\application\controllers\ajax.php 28
ERROR - 2012-07-10 01:08:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-10 01:08:39 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\bitsy-crm\application\controllers\ajax.php 28
ERROR - 2012-07-10 01:08:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-10 01:09:03 --> Severity: Notice  --> Undefined index: recurring C:\wamp\www\bitsy-crm\application\models\core.php 73
ERROR - 2012-07-10 01:11:48 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\bitsy-crm\application\controllers\ajax.php 28
ERROR - 2012-07-10 01:11:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-10 01:12:41 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\bitsy-crm\application\controllers\ajax.php 28
ERROR - 2012-07-10 01:12:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-10 01:12:43 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\bitsy-crm\application\controllers\ajax.php 28
ERROR - 2012-07-10 01:12:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-10 01:12:58 --> Severity: 8192  --> Function split() is deprecated C:\wamp\www\bitsy-crm\application\models\core.php 74
ERROR - 2012-07-10 01:12:58 --> Severity: Notice  --> Undefined index: recurring C:\wamp\www\bitsy-crm\application\models\core.php 76
ERROR - 2012-07-10 01:17:42 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\bitsy-crm\application\controllers\ajax.php 28
ERROR - 2012-07-10 01:17:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-10 01:17:56 --> Severity: 8192  --> Function split() is deprecated C:\wamp\www\bitsy-crm\application\models\core.php 74
ERROR - 2012-07-10 01:17:56 --> Severity: Notice  --> Undefined index: recurring C:\wamp\www\bitsy-crm\application\models\core.php 76
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined property: stdClass::$recur_by C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined property: stdClass::$recur_by C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined property: stdClass::$recur_by C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined property: stdClass::$recur_by C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:22:00 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\bitsy-crm\application\views\client\invoices\page.php 27
ERROR - 2012-07-10 01:34:14 --> 404 Page Not Found --> 404
ERROR - 2012-07-10 02:03:37 --> 404 Page Not Found --> 404
ERROR - 2012-07-10 02:04:42 --> Severity: Warning  --> file_put_contents(/tmp/crontab.txt) [<a href='function.file-put-contents'>function.file-put-contents</a>]: failed to open stream: No such file or directory C:\wamp\www\bitsy-crm\application\controllers\admin\dashboard.php 18
