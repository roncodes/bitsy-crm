<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Configuration options
$config['stripe_key_test_public']         = '';
$config['stripe_key_test_secret']         = '';
$config['stripe_key_live_public']         = '';
$config['stripe_key_live_secret']         = '';
$config['stripe_test_mode']               = TRUE;
$config['stripe_verify_ssl']              = FALSE;