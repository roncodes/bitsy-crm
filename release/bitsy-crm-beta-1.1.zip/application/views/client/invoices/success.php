<div class="panel">
	<div class="page-header">
		<h1>Successful Payment</h1>
	</div>
	<h3>Your payment of <?=_money_format($_POST['payment_gross'])?> has successfully been processed</h3>
	<a href=".." class="btn btn-success">Click here to continue</a>
</div>