<h1>New Reply On Your Ticket</h1>
<?=$user?> have made a reply to ticket #<?=$ticket_id?> (<?=$ticket_subject?>)<br>
<blockquote><?=$reply?></blockquote><br>
Check it out: <a href="<?=base_url()?>"><?=base_url()?></a>