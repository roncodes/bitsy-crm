<?php
file_get_contents(base_url('/cron/generate_recurring_invoices'));
?>