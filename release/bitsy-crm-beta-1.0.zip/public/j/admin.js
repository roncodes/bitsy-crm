$(document).ready(function() {
	$("#inline_debug").fancybox({
		scrolling: 'yes',
		titleShow: false,
		autoDimensions: false,
		width: '75%',
		height: '90%'
	});
	
	$("#inline_profiler").fancybox({
		scrolling: 'yes',
		titleShow: false,
		autoDimensions: false,
		width: '75%',
		height: '90%'
	});
});