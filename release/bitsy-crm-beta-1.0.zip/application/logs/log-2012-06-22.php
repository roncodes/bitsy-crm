<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-22 02:16:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't load the web page properly', '2', '5', '2012-06-22 02:16:15', 'Open')' at line 1
ERROR - 2012-06-22 02:18:04 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\client_manager\application\controllers\client\tickets.php 50
ERROR - 2012-06-22 02:18:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\tickets.php 50
ERROR - 2012-06-22 02:21:48 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\client_manager\application\controllers\client\tickets.php 50
ERROR - 2012-06-22 02:21:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\tickets.php 50
ERROR - 2012-06-22 02:21:48 --> Severity: Notice  --> Undefined index: subject C:\wamp\www\client_manager\application\controllers\client\tickets.php 51
ERROR - 2012-06-22 02:24:31 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\client_manager\application\controllers\client\tickets.php 53
ERROR - 2012-06-22 02:24:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\tickets.php 53
ERROR - 2012-06-22 02:43:45 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\client\tickets\close.php 13
ERROR - 2012-06-22 02:43:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\close.php 13
ERROR - 2012-06-22 02:47:35 --> Query error: Unknown column 'HW2TB' in 'where clause'
ERROR - 2012-06-22 02:54:02 --> Severity: Notice  --> Undefined property: stdClass::$last_update C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-22 02:59:26 --> 404 Page Not Found --> client/profile
ERROR - 2012-06-22 03:02:09 --> Severity: Notice  --> Undefined variable: projects C:\wamp\www\client_manager\application\views\client\profile\index.php 8
ERROR - 2012-06-22 03:02:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-22 03:29:11 --> 404 Page Not Found --> invoices/payments
ERROR - 2012-06-22 03:36:56 --> 404 Page Not Found --> admin/payment-gateways
ERROR - 2012-06-22 03:42:27 --> 404 Page Not Found --> tickets/view
ERROR - 2012-06-22 03:47:32 --> Severity: Notice  --> date_default_timezone_set() [<a href='function.date-default-timezone-set'>function.date-default-timezone-set</a>]: Timezone ID '' is invalid C:\wamp\www\client_manager\application\views\client\tickets\view.php 1
ERROR - 2012-06-22 03:48:07 --> Severity: Notice  --> date_default_timezone_set() [<a href='function.date-default-timezone-set'>function.date-default-timezone-set</a>]: Timezone ID '' is invalid C:\wamp\www\client_manager\application\views\client\tickets\view.php 1
ERROR - 2012-06-22 03:51:26 --> 404 Page Not Found --> admin/gateways
ERROR - 2012-06-22 18:26:49 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-22 18:26:57 --> Severity: Notice  --> Undefined variable: inset_check C:\wamp\www\client_manager\application\models\core.php 377
ERROR - 2012-06-22 18:27:09 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:27:09 --> Severity: Notice  --> Undefined index: auth1 C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:27:09 --> Severity: Notice  --> Undefined index: auth2 C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:27:09 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:28:52 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:28:52 --> Severity: Notice  --> Undefined index: auth1 C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:28:52 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:28:52 --> Severity: Notice  --> Undefined index: active C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:28:59 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:28:59 --> Severity: Notice  --> Undefined index: auth1 C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:28:59 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:31:36 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:31:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:31:36 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:31:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:31:36 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 28
ERROR - 2012-06-22 18:31:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 28
ERROR - 2012-06-22 18:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 28
ERROR - 2012-06-22 18:37:10 --> Severity: Notice  --> Use of undefined constant stdClass - assumed 'stdClass' C:\wamp\www\client_manager\application\models\core.php 366
ERROR - 2012-06-22 18:37:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:37:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:37:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 28
ERROR - 2012-06-22 18:37:35 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:37:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:37:35 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:37:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:37:35 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 28
ERROR - 2012-06-22 18:37:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 28
ERROR - 2012-06-22 18:39:10 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:39:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 25
ERROR - 2012-06-22 18:39:10 --> Severity: Notice  --> Undefined index: stripe C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:39:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\gateways\index.php 26
ERROR - 2012-06-22 18:40:35 --> Severity: Notice  --> Undefined index: login C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:40:35 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:40:35 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:41:39 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:41:39 --> Severity: Notice  --> Undefined index: auth1 C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:41:39 --> Severity: Notice  --> Undefined index: auth2 C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:41:39 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 380
ERROR - 2012-06-22 18:42:10 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:42:10 --> Severity: Notice  --> Undefined index: auth1 C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:42:10 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:42:47 --> Severity: Notice  --> Undefined index: password C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:42:47 --> Severity: Notice  --> Undefined index: auth1 C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:42:47 --> Severity: Notice  --> Undefined index: auth2 C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:42:47 --> Severity: Notice  --> Undefined index: url C:\wamp\www\client_manager\application\models\core.php 378
ERROR - 2012-06-22 18:44:39 --> 404 Page Not Found --> tickets
ERROR - 2012-06-22 18:44:46 --> 404 Page Not Found --> tickets
ERROR - 2012-06-22 18:45:04 --> Severity: Notice  --> date_default_timezone_set() [<a href='function.date-default-timezone-set'>function.date-default-timezone-set</a>]: Timezone ID '' is invalid C:\wamp\www\client_manager\application\views\client\tickets\view.php 1
ERROR - 2012-06-22 18:46:01 --> 404 Page Not Found --> clients/invoices
ERROR - 2012-06-22 18:46:06 --> 404 Page Not Found --> clients/invoices
ERROR - 2012-06-22 18:46:09 --> 404 Page Not Found --> clients/invoices
ERROR - 2012-06-22 19:26:13 --> 404 Page Not Found --> admin/users
ERROR - 2012-06-22 19:31:05 --> 404 Page Not Found --> admin/users
ERROR - 2012-06-22 19:37:31 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-22 19:37:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-22 19:47:08 --> 404 Page Not Found --> invoices/payments
ERROR - 2012-06-22 19:49:06 --> 404 Page Not Found --> invoices/payments
ERROR - 2012-06-22 19:49:11 --> 404 Page Not Found --> invoices/pay
ERROR - 2012-06-22 20:51:17 --> 404 Page Not Found --> invoices
ERROR - 2012-06-22 20:53:42 --> 404 Page Not Found --> clientinvoices
ERROR - 2012-06-22 20:53:45 --> Query error: Unknown column 'cancel' in 'where clause'
ERROR - 2012-06-22 20:54:38 --> Query error: Unknown column 'cancel' in 'where clause'
ERROR - 2012-06-22 20:54:39 --> Query error: Unknown column 'cancel' in 'where clause'
ERROR - 2012-06-22 20:54:39 --> Query error: Unknown column 'cancel' in 'where clause'
ERROR - 2012-06-22 20:55:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-22 21:20:13 --> 404 Page Not Found --> invoices
ERROR - 2012-06-22 21:24:27 --> 404 Page Not Found --> invoices
ERROR - 2012-06-22 21:24:36 --> 404 Page Not Found --> invoices
ERROR - 2012-06-22 21:24:38 --> 404 Page Not Found --> invoices
ERROR - 2012-06-22 21:26:38 --> 404 Page Not Found --> invoices
ERROR - 2012-06-22 21:55:25 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\client\invoices\index.php 22
ERROR - 2012-06-22 21:55:25 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\client\invoices\index.php 22
ERROR - 2012-06-22 21:55:25 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\client\invoices\index.php 22
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Undefined index: item_number C:\wamp\www\client_manager\application\models\core.php 396
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Undefined index: payment_gross C:\wamp\www\client_manager\application\models\core.php 397
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 397
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 397
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Undefined index: payment_gross C:\wamp\www\client_manager\application\models\core.php 399
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 399
ERROR - 2012-06-22 22:11:23 --> Severity: Notice  --> Undefined index: txn_id C:\wamp\www\client_manager\application\models\core.php 399
DEBUG - 2012-06-22 22:36:42 --> Config Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Hooks Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Utf8 Class Initialized
DEBUG - 2012-06-22 22:36:42 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 22:36:42 --> URI Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Router Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Output Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Security Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Input Class Initialized
DEBUG - 2012-06-22 22:36:42 --> XSS Filtering completed
DEBUG - 2012-06-22 22:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 22:36:42 --> Language Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Loader Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: auth_helper
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: form_helper
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: url_helper
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: site_helper
DEBUG - 2012-06-22 22:36:42 --> Database Driver Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Form Validation Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2012-06-22 22:36:42 --> Email Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Session Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: string_helper
DEBUG - 2012-06-22 22:36:42 --> Session routines successfully run
DEBUG - 2012-06-22 22:36:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2012-06-22 22:36:42 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: cookie_helper
DEBUG - 2012-06-22 22:36:42 --> Helper loaded: date_helper
DEBUG - 2012-06-22 22:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:36:42 --> Pagination Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:36:42 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Controller Class Initialized
DEBUG - 2012-06-22 22:36:42 --> Config file loaded: application/config/paypallib_config.php
DEBUG - 2012-06-22 22:36:42 --> File loaded: application/views/client/invoices/index.php
DEBUG - 2012-06-22 22:36:42 --> File loaded: application/views/layouts/application.php
DEBUG - 2012-06-22 22:36:42 --> Final output sent to browser
DEBUG - 2012-06-22 22:36:42 --> Total execution time: 0.1722
DEBUG - 2012-06-22 22:36:43 --> Config Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Hooks Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Utf8 Class Initialized
DEBUG - 2012-06-22 22:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 22:36:43 --> URI Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Router Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Output Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Security Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Input Class Initialized
DEBUG - 2012-06-22 22:36:43 --> XSS Filtering completed
DEBUG - 2012-06-22 22:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 22:36:43 --> Language Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Loader Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Helper loaded: auth_helper
DEBUG - 2012-06-22 22:36:43 --> Helper loaded: form_helper
DEBUG - 2012-06-22 22:36:43 --> Helper loaded: url_helper
DEBUG - 2012-06-22 22:36:43 --> Helper loaded: site_helper
DEBUG - 2012-06-22 22:36:43 --> Database Driver Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Form Validation Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2012-06-22 22:36:43 --> Email Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Session Class Initialized
DEBUG - 2012-06-22 22:36:43 --> Helper loaded: string_helper
DEBUG - 2012-06-22 22:36:43 --> Session routines successfully run
DEBUG - 2012-06-22 22:36:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2012-06-22 22:36:44 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:44 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:44 --> Helper loaded: cookie_helper
DEBUG - 2012-06-22 22:36:44 --> Helper loaded: date_helper
DEBUG - 2012-06-22 22:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:36:44 --> Pagination Class Initialized
DEBUG - 2012-06-22 22:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:36:44 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:44 --> Controller Class Initialized
DEBUG - 2012-06-22 22:36:44 --> Config file loaded: application/config/paypallib_config.php
DEBUG - 2012-06-22 22:36:44 --> File loaded: application/views/client/invoices/pay.php
DEBUG - 2012-06-22 22:36:44 --> File loaded: application/views/layouts/application.php
DEBUG - 2012-06-22 22:36:44 --> Final output sent to browser
DEBUG - 2012-06-22 22:36:44 --> Total execution time: 0.1674
DEBUG - 2012-06-22 22:36:48 --> Config Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Hooks Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Utf8 Class Initialized
DEBUG - 2012-06-22 22:36:48 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 22:36:48 --> URI Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Router Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Output Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Security Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Input Class Initialized
DEBUG - 2012-06-22 22:36:48 --> XSS Filtering completed
DEBUG - 2012-06-22 22:36:48 --> XSS Filtering completed
DEBUG - 2012-06-22 22:36:48 --> XSS Filtering completed
DEBUG - 2012-06-22 22:36:48 --> XSS Filtering completed
DEBUG - 2012-06-22 22:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 22:36:48 --> Language Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Loader Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: auth_helper
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: form_helper
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: url_helper
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: site_helper
DEBUG - 2012-06-22 22:36:48 --> Database Driver Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Form Validation Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2012-06-22 22:36:48 --> Email Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Session Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: string_helper
DEBUG - 2012-06-22 22:36:48 --> Session routines successfully run
DEBUG - 2012-06-22 22:36:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2012-06-22 22:36:48 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: cookie_helper
DEBUG - 2012-06-22 22:36:48 --> Helper loaded: date_helper
DEBUG - 2012-06-22 22:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:36:48 --> Pagination Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:36:48 --> Model Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Controller Class Initialized
DEBUG - 2012-06-22 22:36:48 --> Config file loaded: application/config/paypallib_config.php
DEBUG - 2012-06-22 22:36:48 --> File loaded: application/views/client/invoices/pay.php
DEBUG - 2012-06-22 22:36:48 --> File loaded: application/views/layouts/application.php
DEBUG - 2012-06-22 22:36:48 --> Final output sent to browser
DEBUG - 2012-06-22 22:36:48 --> Total execution time: 0.1746
DEBUG - 2012-06-22 22:37:23 --> Config Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Hooks Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Utf8 Class Initialized
DEBUG - 2012-06-22 22:37:23 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 22:37:23 --> URI Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Router Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Output Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Security Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Input Class Initialized
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> XSS Filtering completed
DEBUG - 2012-06-22 22:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 22:37:23 --> Language Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Loader Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: auth_helper
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: form_helper
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: url_helper
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: site_helper
DEBUG - 2012-06-22 22:37:23 --> Database Driver Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Form Validation Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2012-06-22 22:37:23 --> Email Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Session Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: string_helper
DEBUG - 2012-06-22 22:37:23 --> Session routines successfully run
DEBUG - 2012-06-22 22:37:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2012-06-22 22:37:23 --> Model Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Model Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: cookie_helper
DEBUG - 2012-06-22 22:37:23 --> Helper loaded: date_helper
DEBUG - 2012-06-22 22:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:37:23 --> Pagination Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2012-06-22 22:37:23 --> Model Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Controller Class Initialized
DEBUG - 2012-06-22 22:37:23 --> Config file loaded: application/config/paypallib_config.php
DEBUG - 2012-06-22 22:37:23 --> File loaded: application/views/client/invoices/success.php
DEBUG - 2012-06-22 22:37:24 --> File loaded: application/views/layouts/application.php
DEBUG - 2012-06-22 22:37:24 --> Final output sent to browser
DEBUG - 2012-06-22 22:37:24 --> Total execution time: 0.2949
ERROR - 2012-06-22 18:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 5
ERROR - 2012-06-22 18:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 8
ERROR - 2012-06-22 18:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 10
ERROR - 2012-06-22 18:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 13
ERROR - 2012-06-22 18:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 13
ERROR - 2012-06-22 18:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 14
