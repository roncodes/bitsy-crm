<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-14 00:58:29 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-14 01:04:24 --> 404 Page Not Found --> client/profile
ERROR - 2012-06-14 01:09:28 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-14 01:09:55 --> 404 Page Not Found --> tickets/view
ERROR - 2012-06-14 01:10:35 --> 404 Page Not Found --> tickets/view
ERROR - 2012-06-14 01:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 3
ERROR - 2012-06-14 01:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 6
ERROR - 2012-06-14 01:30:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 3
ERROR - 2012-06-14 01:30:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\view.php 7
ERROR - 2012-06-14 02:27:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\tickets.php 48
