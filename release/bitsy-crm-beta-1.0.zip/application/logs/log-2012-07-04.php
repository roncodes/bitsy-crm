<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Undefined property: stdClass::$client C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Undefined property: stdClass::$client C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Undefined property: stdClass::$client C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Undefined property: stdClass::$client C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Undefined property: stdClass::$client C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:26:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 340
ERROR - 2012-07-04 02:29:27 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-07-04 02:29:27 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-07-04 02:29:27 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-07-04 02:29:27 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-07-04 02:29:27 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-07-04 08:59:54 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
