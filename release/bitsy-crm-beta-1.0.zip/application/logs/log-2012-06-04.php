<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-04 00:10:38 --> 404 Page Not Found --> admin/tickets
ERROR - 2012-06-04 00:12:06 --> 404 Page Not Found --> invoices/create
ERROR - 2012-06-04 00:13:11 --> Severity: Notice  --> Undefined variable: clients C:\wamp\www\client_manager\application\views\admin\invoices\create.php 8
ERROR - 2012-06-04 00:13:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:13:11 --> Severity: Notice  --> Undefined variable: groups C:\wamp\www\client_manager\application\views\admin\invoices\create.php 10
ERROR - 2012-06-04 00:13:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:13:11 --> Severity: Notice  --> Undefined variable: status C:\wamp\www\client_manager\application\views\admin\invoices\create.php 11
ERROR - 2012-06-04 00:13:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:13:11 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 8
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 8
ERROR - 2012-06-04 00:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 9
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 9
ERROR - 2012-06-04 00:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 10
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 10
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 11
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 11
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 12
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 12
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 14
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 14
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 14
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 29
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 29
ERROR - 2012-06-04 00:14:41 --> Severity: Notice  --> Undefined variable: invoice_id C:\wamp\www\client_manager\application\views\admin\invoices\create.php 30
ERROR - 2012-06-04 00:14:41 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 00:15:55 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 9
ERROR - 2012-06-04 00:15:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 9
ERROR - 2012-06-04 00:15:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:15:55 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\create.php 10
ERROR - 2012-06-04 00:15:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\create.php 10
ERROR - 2012-06-04 00:15:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:15:55 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 00:16:14 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\invoices\create.php on line 9 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 87
ERROR - 2012-06-04 00:16:14 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 95
ERROR - 2012-06-04 00:16:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:16:14 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\invoices\create.php on line 10 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 87
ERROR - 2012-06-04 00:16:14 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 95
ERROR - 2012-06-04 00:16:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-04 00:16:15 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 00:16:38 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 00:16:46 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 00:17:14 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 01:18:47 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 01:19:34 --> 404 Page Not Found --> admin/admin
ERROR - 2012-06-04 01:19:44 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:19:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-04 01:20:04 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 01:20:51 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-04 01:20:54 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-04 01:20:55 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-04 01:20:58 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-04 01:20:58 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-04 01:21:02 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-04 01:21:04 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-04 01:21:06 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-04 01:21:07 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-04 01:21:25 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-04 01:21:27 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-04 01:21:29 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-04 01:21:29 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 01:21:40 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-04 01:21:43 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 01:21:43 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-04 01:23:57 --> 404 Page Not Found --> projects
ERROR - 2012-06-04 01:23:57 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-04 01:23:57 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:23:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-04 01:24:43 --> 404 Page Not Found --> admin/admin
ERROR - 2012-06-04 01:24:52 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:24:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-04 01:25:41 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:25:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-04 01:25:43 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:25:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-04 01:25:47 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:25:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-04 01:25:48 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-04 01:25:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
