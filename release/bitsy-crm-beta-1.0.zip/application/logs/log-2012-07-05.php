<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-07-05 15:41:19 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-07-05 18:50:07 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-07-05 18:54:28 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-07-05 18:54:40 --> 404 Page Not Found --> projects/view
ERROR - 2012-07-05 18:54:49 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-07-05 18:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\projects.php 26
ERROR - 2012-07-05 19:00:24 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-07-05 19:25:55 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:26:02 --> Severity: Notice  --> Undefined index: site_name C:\wamp\www\client_manager\application\views\layouts\admin.php 44
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined variable: setting C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 20
ERROR - 2012-07-05 19:26:13 --> Severity: Notice  --> Undefined index: site_name C:\wamp\www\client_manager\application\views\layouts\admin.php 44
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:28:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 18
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 21
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 22
ERROR - 2012-07-05 19:30:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:31 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Undefined variable: option C:\wamp\www\client_manager\application\views\admin\options\index.php 19
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:30:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 23
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$value C:\wamp\www\client_manager\application\views\admin\options\index.php 24
ERROR - 2012-07-05 19:31:08 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:31:43 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\client_manager\application\views\admin\options\index.php 25
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 13 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 14 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 15 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 16 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 17 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 18 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:33:07 --> Severity: Notice  --> Undefined offset: 19 C:\wamp\www\client_manager\application\views\admin\options\page.php 17
ERROR - 2012-07-05 19:36:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'fds'fds"FDS', 'mdsionfdisoaf', '2', '7', 'Open')' at line 1
ERROR - 2012-07-05 19:40:26 --> Severity: Notice  --> Undefined variable: row_start C:\wamp\www\client_manager\application\views\admin\tickets\index.php 14
ERROR - 2012-07-05 19:40:26 --> Severity: Notice  --> Undefined variable: row_start C:\wamp\www\client_manager\application\views\admin\tickets\index.php 14
ERROR - 2012-07-05 19:40:26 --> Severity: Notice  --> Undefined variable: per_page C:\wamp\www\client_manager\application\views\admin\tickets\index.php 14
ERROR - 2012-07-05 19:40:26 --> Severity: Notice  --> Undefined variable: links C:\wamp\www\client_manager\application\views\admin\tickets\index.php 29
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Undefined variable: tickets C:\wamp\www\client_manager\application\controllers\admin\tickets.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Undefined variable: ticket C:\wamp\www\client_manager\application\views\admin\tickets\index.php 16
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Undefined variable: ticket C:\wamp\www\client_manager\application\views\admin\tickets\index.php 16
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 19
ERROR - 2012-07-05 19:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 23
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Undefined variable: ticket C:\wamp\www\client_manager\application\views\admin\tickets\index.php 17
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 20
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 21
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 22
ERROR - 2012-07-05 19:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\tickets\index.php 24
ERROR - 2012-07-05 21:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 518
ERROR - 2012-07-05 21:20:02 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:43:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 518
ERROR - 2012-07-05 21:43:38 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:46:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 518
ERROR - 2012-07-05 21:46:38 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 518
ERROR - 2012-07-05 21:49:55 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 519
ERROR - 2012-07-05 21:53:01 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:53:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 519
ERROR - 2012-07-05 21:53:16 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:53:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 519
ERROR - 2012-07-05 21:53:51 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:54:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 519
ERROR - 2012-07-05 21:54:13 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:55:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\ion_auth_model.php 519
ERROR - 2012-07-05 21:55:14 --> Query error: Column 'group_id' cannot be null
ERROR - 2012-07-05 21:58:54 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-07-05 21:58:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-05 21:58:59 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-07-05 21:58:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-05 21:59:39 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-07-05 21:59:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-07-05 22:21:46 --> Severity: Notice  --> Undefined variable: row_start C:\wamp\www\client_manager\application\views\client\invoices\index.php 17
ERROR - 2012-07-05 22:21:46 --> Severity: Notice  --> Undefined variable: row_start C:\wamp\www\client_manager\application\views\client\invoices\index.php 17
ERROR - 2012-07-05 22:21:46 --> Severity: Notice  --> Undefined variable: per_page C:\wamp\www\client_manager\application\views\client\invoices\index.php 17
ERROR - 2012-07-05 22:21:46 --> Severity: Notice  --> Undefined variable: links C:\wamp\www\client_manager\application\views\client\invoices\index.php 38
