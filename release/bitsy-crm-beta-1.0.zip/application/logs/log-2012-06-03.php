<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-03 00:00:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'VALUES ('33', '2', '5', '1|web dev|general web dev|150|3', '', 'this is a test i' at line 1
ERROR - 2012-06-03 00:02:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'VALUES ('33', '2', '5', '1|web dev|general web dev|150|3', '', 'this is a test i' at line 1
ERROR - 2012-06-03 00:02:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'VALUES ('33', '2', '5', '1|web dev|general web dev|150|3', '$0.00', 'this is a t' at line 1
ERROR - 2012-06-03 00:04:37 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:04:55 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 00:04:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 00:05:14 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:05:17 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 00:05:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 00:05:21 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:05:44 --> 404 Page Not Found --> admin/invoices
ERROR - 2012-06-03 00:09:55 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:09:56 --> Severity: Notice  --> Undefined property: stdClass::$client C:\wamp\www\client_manager\application\controllers\admin\invoices.php 26
ERROR - 2012-06-03 00:09:56 --> Severity: Notice  --> Undefined variable: invoices C:\wamp\www\client_manager\application\views\admin\invoices\index.php 5
ERROR - 2012-06-03 00:09:56 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:10:15 --> Severity: Notice  --> Undefined variable: invoices C:\wamp\www\client_manager\application\views\admin\invoices\index.php 5
ERROR - 2012-06-03 00:10:16 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:10:24 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:11:02 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:11:05 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:11:24 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:11:26 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:11:27 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:12:26 --> Severity: Notice  --> Undefined variable: projects C:\wamp\www\client_manager\application\views\admin\invoices\index.php 19
ERROR - 2012-06-03 00:12:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\application\views\admin\invoices\index.php 19
ERROR - 2012-06-03 00:12:26 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:12:51 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:13:09 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:15:11 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:20:07 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:25:27 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:25:28 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:25:31 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 00:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 00:25:32 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:25:34 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 00:25:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 00:25:36 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:28:04 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:28:06 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:28:41 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:29:08 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:30:04 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:30:19 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:33:43 --> Severity: Notice  --> Undefined property: stdClass::$amount_due C:\wamp\www\client_manager\application\views\admin\invoices\index.php 23
ERROR - 2012-06-03 00:33:43 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:34:23 --> Severity: Notice  --> Undefined property: stdClass::$amount_due C:\wamp\www\client_manager\application\views\admin\invoices\index.php 24
ERROR - 2012-06-03 00:34:23 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:35:09 --> Severity: Notice  --> Undefined property: stdClass::$amount_due C:\wamp\www\client_manager\application\views\admin\invoices\index.php 24
ERROR - 2012-06-03 00:35:09 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:36:21 --> Severity: Notice  --> Undefined variable: total C:\wamp\www\client_manager\application\controllers\admin\invoices.php 39
ERROR - 2012-06-03 00:36:21 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:36:35 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:42:02 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:50:07 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\invoices.php 24
ERROR - 2012-06-03 00:50:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 00:52:06 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\admin\invoices\view.php 33
ERROR - 2012-06-03 00:52:06 --> Severity: Notice  --> Undefined property: stdClass::$invoice_description C:\wamp\www\client_manager\application\views\admin\invoices\view.php 57
ERROR - 2012-06-03 00:52:06 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\admin\invoices\view.php 66
ERROR - 2012-06-03 00:52:06 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\admin\invoices\view.php 76
ERROR - 2012-06-03 00:52:06 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:52:37 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\admin\invoices\view.php 33
ERROR - 2012-06-03 00:52:37 --> Severity: Notice  --> Undefined property: stdClass::$invoice_description C:\wamp\www\client_manager\application\views\admin\invoices\view.php 57
ERROR - 2012-06-03 00:52:37 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\admin\invoices\view.php 66
ERROR - 2012-06-03 00:52:37 --> Severity: Notice  --> Undefined property: stdClass::$subtotal C:\wamp\www\client_manager\application\views\admin\invoices\view.php 76
ERROR - 2012-06-03 00:52:38 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:53:02 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\admin\invoices\view.php 33
ERROR - 2012-06-03 00:53:02 --> Severity: Notice  --> Undefined property: stdClass::$invoice_description C:\wamp\www\client_manager\application\views\admin\invoices\view.php 57
ERROR - 2012-06-03 00:53:02 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:53:27 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\admin\invoices\view.php 33
ERROR - 2012-06-03 00:53:27 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:54:02 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:54:43 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:55:27 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:59:28 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:59:47 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:59:50 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 00:59:58 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 00:59:59 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 01:00:00 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:12:11 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:12:13 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:12:15 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:12:18 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 03:12:38 --> 404 Page Not Found --> invoices/create
ERROR - 2012-06-03 03:12:42 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:13:54 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:02 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:14:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 112
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:16:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 113
ERROR - 2012-06-03 03:17:49 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:18:38 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:22:30 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:22:41 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:22:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\view.php 54
ERROR - 2012-06-03 03:22:57 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 03:23:40 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:25:04 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:25:08 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:26:12 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:26:15 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:26:18 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 03:26:34 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:26:57 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:27:02 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 03:27:24 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:27:29 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 03:27:32 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:27:37 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:28:36 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:28:44 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:28:45 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:28:46 --> 404 Page Not Found --> admin/tickets
ERROR - 2012-06-03 03:28:49 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:28:53 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-03 03:28:58 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:00 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-03 03:29:05 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-03 03:29:08 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:10 --> 404 Page Not Found --> admin/preview_invoice
ERROR - 2012-06-03 03:29:17 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:24 --> 404 Page Not Found --> options/preview_invoice
ERROR - 2012-06-03 03:29:27 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:30 --> 404 Page Not Found --> options/preview_invoice
ERROR - 2012-06-03 03:29:32 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:33 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:37 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:41 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 03:29:45 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 03:29:50 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 04:31:11 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:05:19 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 20:06:01 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:06:02 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:06:09 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:06:10 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:06:15 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 20:07:33 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 20:07:46 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 20:07:47 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 20:07:52 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:09:44 --> 404 Page Not Found --> invoices/invoice
ERROR - 2012-06-03 20:09:48 --> 404 Page Not Found --> preview_invoice
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 6
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 6
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 7
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 7
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: clients C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 8
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 8
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 8
ERROR - 2012-06-03 20:09:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 9
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 9
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: groups C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 10
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 10
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 10
ERROR - 2012-06-03 20:09:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: status C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 11
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 11
ERROR - 2012-06-03 20:09:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 11
ERROR - 2012-06-03 20:09:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-03 20:09:50 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 6
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 6
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 7
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 7
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: clients C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 8
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 8
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 8
ERROR - 2012-06-03 20:25:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 9
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 9
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: groups C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 10
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 10
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 10
ERROR - 2012-06-03 20:25:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: status C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 11
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 11
ERROR - 2012-06-03 20:25:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 11
ERROR - 2012-06-03 20:25:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-03 20:25:36 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 20:26:35 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 20:26:36 --> 404 Page Not Found --> invoices/preview_invoice
ERROR - 2012-06-03 20:27:41 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 20:28:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 20:33:26 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\client_manager\application\views\admin\invoices\edit.php 28
ERROR - 2012-06-03 20:35:47 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 20:35:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 20:36:07 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 20:36:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 20:39:23 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\close.php 13
ERROR - 2012-06-03 20:39:23 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 20:39:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 20:40:14 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 20:40:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 20:48:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 20:48:29 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 20:48:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 20:48:31 --> 404 Page Not Found --> 
ERROR - 2012-06-03 20:51:55 --> 404 Page Not Found --> invoices/open
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 114
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 122
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 129
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 114
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 122
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:02 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Warning  --> Attempt to modify property of non-object C:\wamp\www\client_manager\application\models\core.php 242
ERROR - 2012-06-03 21:06:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 129
ERROR - 2012-06-03 21:09:33 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:09:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 21:09:47 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:09:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 21:54:18 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:54:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 21:54:59 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:54:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 21:55:07 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:55:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 21:55:39 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:55:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 21:55:44 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 21:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:11:18 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:11:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:12:34 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:12:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 150
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 2
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 22
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 28
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 32
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 65
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 70
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 80
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:15:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:15:24 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 2
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 2
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 18
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 22
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 22
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 28
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 28
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 32
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 32
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 65
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 65
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 70
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 70
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 80
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 80
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:21:22 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 90
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:22:30 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:30 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:30 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:30 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:23:02 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:24 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:25 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:25 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:25 --> Severity: Warning  --> DOMXPath::query() [<a href='domxpath.query'>domxpath.query</a>]: Invalid expression C:\wamp\www\client_manager\application\third_party\dompdf\include\stylesheet.cls.php 810
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\client_manager\application\third_party\dompdf\include\table_frame_reflower.cls.php 396
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:23:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:24:13 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:24:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:24:13 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:24:13 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:24:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:24:13 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:24:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:24:28 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:24:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:24:28 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:24:28 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:24:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:24:28 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:24:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:25:11 --> Severity: Notice  --> Undefined variable: view C:\wamp\www\client_manager\application\controllers\admin\invoices.php 8
ERROR - 2012-06-03 22:26:09 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:26:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:26:19 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:26:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:27:57 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:27:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:28:01 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:28:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:28:01 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:28:01 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:28:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:28:01 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:28:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 22:29:55 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:29:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:29:55 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:29:55 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:29:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:29:55 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:29:58 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:29:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 5
ERROR - 2012-06-03 22:29:58 --> Severity: Notice  --> Undefined variable: csrf C:\wamp\www\client_manager\application\views\admin\invoices\download.php 13
ERROR - 2012-06-03 22:29:58 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:29:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\download.php 14
ERROR - 2012-06-03 22:31:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 2
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 2
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 7
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 8
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 9
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 12
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 13
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 18
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 22
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 22
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 28
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 28
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 32
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 32
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 36
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 53
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 65
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 65
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 70
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 70
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 75
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 80
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 80
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 85
ERROR - 2012-06-03 22:34:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\invoices\pdf_view.php 90
ERROR - 2012-06-03 22:35:30 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:40:27 --> Severity: Notice  --> Undefined variable: html C:\wamp\www\client_manager\application\controllers\admin\invoices.php 119
ERROR - 2012-06-03 22:47:33 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:48:28 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:57:18 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 22:57:21 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 22:57:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 23:06:54 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 23:06:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 23:11:12 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-03 23:11:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-03 23:32:04 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 23:34:28 --> 404 Page Not Found --> projects
ERROR - 2012-06-03 23:42:56 --> 404 Page Not Found --> projects
