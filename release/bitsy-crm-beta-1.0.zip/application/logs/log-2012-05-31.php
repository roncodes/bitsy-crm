<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-05-31 19:39:15 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:39:15 --> Unable to connect to the database
ERROR - 2012-05-31 19:41:19 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:41:19 --> Unable to connect to the database
ERROR - 2012-05-31 19:41:36 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:41:36 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:41:36 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:41:36 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given C:\wamp\www\client_manager\application\core\MY_Controller.php 14
ERROR - 2012-05-31 19:41:36 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\core\MY_Controller.php 16
ERROR - 2012-05-31 19:42:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:42:31 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:42:31 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:42:31 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given C:\wamp\www\client_manager\application\core\MY_Controller.php 14
ERROR - 2012-05-31 19:42:31 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\core\MY_Controller.php 16
ERROR - 2012-05-31 19:42:33 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:42:33 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:42:33 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given C:\wamp\www\client_manager\application\core\MY_Controller.php 14
ERROR - 2012-05-31 19:42:33 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\core\MY_Controller.php 16
ERROR - 2012-05-31 19:42:52 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:42:52 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:42:52 --> Severity: Warning  --> array_key_exists() expects parameter 2 to be array, boolean given C:\wamp\www\client_manager\application\core\MY_Controller.php 14
ERROR - 2012-05-31 19:42:52 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\core\MY_Controller.php 16
ERROR - 2012-05-31 19:43:46 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:43:46 --> Severity: Notice  --> Use of undefined constant SYSTEM_NAME - assumed 'SYSTEM_NAME' C:\wamp\www\client_manager\application\config\ion_auth.php 30
ERROR - 2012-05-31 19:44:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:44:51 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:47:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 19:48:10 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-05-31 21:15:38 --> 404 Page Not Found --> admin/users
ERROR - 2012-05-31 21:38:53 --> 404 Page Not Found --> admin/projects
ERROR - 2012-05-31 21:48:49 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\projects\create.php on line 7 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 67
ERROR - 2012-05-31 21:48:49 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 75
ERROR - 2012-05-31 21:48:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 21:48:49 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\projects\create.php on line 9 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 67
ERROR - 2012-05-31 21:48:49 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 75
ERROR - 2012-05-31 21:48:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 21:52:10 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\projects\create.php on line 9 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 67
ERROR - 2012-05-31 21:52:10 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 75
ERROR - 2012-05-31 21:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 22:18:03 --> 404 Page Not Found --> projects/project_groups
ERROR - 2012-05-31 22:20:36 --> 404 Page Not Found --> projects/groups
ERROR - 2012-05-31 22:21:21 --> Severity: Notice  --> Undefined variable: users C:\wamp\www\client_manager\application\views\admin\projects\groups.php 18
ERROR - 2012-05-31 22:21:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\application\views\admin\projects\groups.php 18
ERROR - 2012-05-31 22:32:30 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\projects\create.php on line 9 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 67
ERROR - 2012-05-31 22:32:30 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 75
ERROR - 2012-05-31 22:32:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 22:48:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:48:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:49:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:50:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:51:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:53:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:54:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 22:59:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 23:00:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 23:00:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'test project for my test clients', '2', '50.00',' at line 1
ERROR - 2012-05-31 23:01:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'group, status) VALUES ('Test', 'A test project for my test client', '2', '50.00'' at line 1
ERROR - 2012-05-31 23:01:40 --> Query error: Unknown column 'client' in 'field list'
ERROR - 2012-05-31 23:04:01 --> Severity: Notice  --> Undefined variable: users C:\wamp\www\client_manager\application\views\admin\projects\index.php 21
ERROR - 2012-05-31 23:04:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\application\views\admin\projects\index.php 21
ERROR - 2012-05-31 23:05:25 --> Severity: Notice  --> Undefined property: stdClass::$group C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-05-31 23:05:25 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-05-31 23:05:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-05-31 23:05:25 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-05-31 23:05:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-05-31 23:05:34 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-05-31 23:05:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-05-31 23:05:34 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-05-31 23:05:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-05-31 23:13:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\delete.php 5
ERROR - 2012-05-31 23:13:04 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\delete.php 14
ERROR - 2012-05-31 23:13:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\delete.php 14
ERROR - 2012-05-31 23:13:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\delete.php 6
ERROR - 2012-05-31 23:13:50 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\delete.php 15
ERROR - 2012-05-31 23:13:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\delete.php 15
ERROR - 2012-05-31 23:14:09 --> Severity: Notice  --> Undefined variable: user C:\wamp\www\client_manager\application\views\admin\projects\delete.php 15
ERROR - 2012-05-31 23:14:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\delete.php 15
ERROR - 2012-05-31 23:20:52 --> Severity: Notice  --> Undefined property: stdClass::$first_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:20:52 --> Severity: Notice  --> Undefined property: stdClass::$last_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:20:52 --> Severity: Notice  --> Undefined property: stdClass::$first_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:20:52 --> Severity: Notice  --> Undefined property: stdClass::$last_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:20:52 --> Severity: Notice  --> Undefined property: stdClass::$first_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:20:52 --> Severity: Notice  --> Undefined property: stdClass::$last_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:21:22 --> Severity: Notice  --> Undefined property: stdClass::$first_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:21:22 --> Severity: Notice  --> Undefined property: stdClass::$last_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:21:22 --> Severity: Notice  --> Undefined property: stdClass::$first_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:21:22 --> Severity: Notice  --> Undefined property: stdClass::$last_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:21:22 --> Severity: Notice  --> Undefined property: stdClass::$first_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:21:22 --> Severity: Notice  --> Undefined property: stdClass::$last_name C:\wamp\www\client_manager\application\controllers\admin\projects.php 252
ERROR - 2012-05-31 23:27:49 --> Severity: Notice  --> Undefined variable: clients C:\wamp\www\client_manager\application\views\admin\projects\edit.php 8
ERROR - 2012-05-31 23:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 23:27:49 --> Severity: Notice  --> Undefined variable: groups C:\wamp\www\client_manager\application\views\admin\projects\edit.php 10
ERROR - 2012-05-31 23:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 23:27:49 --> Severity: Notice  --> Undefined variable: status C:\wamp\www\client_manager\application\views\admin\projects\edit.php 11
ERROR - 2012-05-31 23:27:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-05-31 23:29:47 --> Severity: Notice  --> Undefined property: stdClass::$group C:\wamp\www\client_manager\application\views\admin\projects\edit.php 10
ERROR - 2012-05-31 23:30:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1
ERROR - 2012-05-31 23:41:23 --> Severity: Notice  --> Undefined variable: groups C:\wamp\www\client_manager\application\views\admin\projects\update.php 16
ERROR - 2012-05-31 23:41:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\application\views\admin\projects\update.php 16
ERROR - 2012-05-31 23:44:38 --> Severity: Notice  --> Undefined variable: updates C:\wamp\www\client_manager\application\views\admin\projects\update.php 7
ERROR - 2012-05-31 23:44:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\application\views\admin\projects\update.php 7
ERROR - 2012-05-31 23:49:30 --> Query error: Unknown column 'name' in 'field list'
ERROR - 2012-05-31 23:56:29 --> 404 Page Not Found --> admin/tickets
