<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-06 00:59:29 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-06 00:59:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\helpers\auth_helper.php 19
ERROR - 2012-06-06 01:00:24 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-06 01:00:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\helpers\auth_helper.php 19
ERROR - 2012-06-06 01:00:30 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-06 01:00:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\helpers\auth_helper.php 19
ERROR - 2012-06-06 01:00:51 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-06 01:01:49 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-06 01:11:25 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-06 01:15:32 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 151
ERROR - 2012-06-06 01:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 152
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 151
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 152
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 4
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:17:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 24
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 30
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 34
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 67
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 72
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 82
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 01:17:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 151
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 152
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 4
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 24
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 30
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 34
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 67
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 72
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 82
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 01:18:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 02:02:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 301
ERROR - 2012-06-06 02:02:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\models\core.php 302
ERROR - 2012-06-06 02:18:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-06 02:19:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-06 02:22:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 18
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 22
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:56:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 19
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 20
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 21
ERROR - 2012-06-06 02:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\tickets\index.php 23
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 151
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 35
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 4
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 24
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 30
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 34
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 67
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 72
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 82
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 03:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 151
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 35
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 4
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 9
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 10
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 03:03:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 11
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 14
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 15
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 24
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 30
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 34
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 38
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 55
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 67
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 72
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 77
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 82
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 03:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\invoices\view.php 87
ERROR - 2012-06-06 03:04:14 --> 404 Page Not Found --> invoices/payments
ERROR - 2012-06-06 03:04:26 --> 404 Page Not Found --> client/profile
ERROR - 2012-06-06 03:15:51 --> 404 Page Not Found --> client/profile
