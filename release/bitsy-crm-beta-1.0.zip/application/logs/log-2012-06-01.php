<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-01 00:04:43 --> Severity: Notice  --> Undefined property: stdClass::$address C:\wamp\www\client_manager\application\views\admin\clients\edit.php 12
ERROR - 2012-06-01 00:06:30 --> Severity: Notice  --> Undefined property: stdClass::$address C:\wamp\www\client_manager\application\views\admin\clients\edit.php 12
ERROR - 2012-06-01 00:08:04 --> Severity: Notice  --> Undefined property: stdClass::$address C:\wamp\www\client_manager\application\views\admin\clients\edit.php 12
ERROR - 2012-06-01 00:41:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 23
ERROR - 2012-06-01 00:42:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 24
ERROR - 2012-06-01 00:44:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 24
ERROR - 2012-06-01 00:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 42
ERROR - 2012-06-01 00:56:31 --> Severity: Notice  --> Undefined index: company_address C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 42
ERROR - 2012-06-01 01:00:06 --> Query error: Unknown column 'public' in 'where clause'
ERROR - 2012-06-01 01:02:38 --> 404 Page Not Found --> admin/tickets
ERROR - 2012-06-01 02:10:24 --> Severity: Notice  --> Undefined variable: _GLOBALS C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 22
ERROR - 2012-06-01 02:10:41 --> Severity: Notice  --> Undefined variable: _GLOBALS C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 22
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:08 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:09 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:11 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:12 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:13 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:14 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:15 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:17 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:18 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:19 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:20 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:22 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:23 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:24 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:25 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:26 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:27 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:29 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:30 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:31 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:32 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:33 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:35 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:36 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:37 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:39 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:40 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:41 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 7
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 8
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 9
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 12
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: client C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 13
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 18
ERROR - 2012-06-01 02:22:42 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 83
ERROR - 2012-06-01 02:28:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-01 02:28:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-01 02:28:25 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\controllers\admin\projects.php 29
ERROR - 2012-06-01 02:28:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\admin\projects.php 29
ERROR - 2012-06-01 02:30:38 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\client_manager\application\views\admin\projects\invoice.php 11
ERROR - 2012-06-01 02:32:44 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\controllers\admin\projects.php 29
ERROR - 2012-06-01 02:32:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\admin\projects.php 29
ERROR - 2012-06-01 02:40:38 --> 404 Page Not Found --> projects/admin
ERROR - 2012-06-01 03:01:42 --> Severity: Notice  --> Undefined variable: preview_invoice C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 2
ERROR - 2012-06-01 03:01:46 --> Severity: Notice  --> Undefined variable: preview_invoice C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 2
ERROR - 2012-06-01 03:01:47 --> Severity: Notice  --> Undefined variable: preview_invoice C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 2
ERROR - 2012-06-01 03:01:49 --> Severity: Notice  --> Undefined variable: preview_invoice C:\wamp\www\client_manager\application\views\admin\projects\preview_invoice.php 2
