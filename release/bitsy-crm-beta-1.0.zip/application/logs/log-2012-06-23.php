<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-23 00:33:25 --> Severity: Notice  --> Undefined index: amount C:\wamp\www\client_manager\application\controllers\client\invoices.php 73
ERROR - 2012-06-23 00:33:25 --> Severity: Notice  --> Undefined index: stripe_key_test_secret C:\wamp\www\client_manager\application\libraries\Stripe.php 391
ERROR - 2012-06-23 00:33:25 --> Severity: Notice  --> Undefined index: stripe_verify_ssl C:\wamp\www\client_manager\application\libraries\Stripe.php 397
ERROR - 2012-06-23 00:33:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 74
ERROR - 2012-06-23 00:33:25 --> Severity: Notice  --> Undefined index: amount C:\wamp\www\client_manager\application\controllers\client\invoices.php 78
ERROR - 2012-06-23 00:34:10 --> Severity: Notice  --> Undefined index: amount C:\wamp\www\client_manager\application\controllers\client\invoices.php 73
ERROR - 2012-06-23 00:34:10 --> Severity: Notice  --> Undefined index: stripe_key_test_secret C:\wamp\www\client_manager\application\libraries\Stripe.php 391
ERROR - 2012-06-23 00:34:10 --> Severity: Notice  --> Undefined index: stripe_verify_ssl C:\wamp\www\client_manager\application\libraries\Stripe.php 397
ERROR - 2012-06-23 00:43:26 --> Severity: Notice  --> Undefined property: stdClass::$error C:\wamp\www\client_manager\application\controllers\client\invoices.php 78
ERROR - 2012-06-23 00:47:40 --> Severity: Notice  --> Undefined property: stdClass::$error C:\wamp\www\client_manager\application\controllers\client\invoices.php 78
ERROR - 2012-06-23 00:50:42 --> Severity: Notice  --> Undefined property: stdClass::$error C:\wamp\www\client_manager\application\controllers\client\invoices.php 78
ERROR - 2012-06-23 00:51:03 --> Severity: Notice  --> Undefined property: stdClass::$error C:\wamp\www\client_manager\application\controllers\client\invoices.php 78
ERROR - 2012-06-23 00:57:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-23 00:57:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-23 00:57:53 --> 404 Page Not Found --> client/dashboard
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 6
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 7
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 8
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 9
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 10
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 11
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 12
ERROR - 2012-06-23 00:57:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\client\profile\index.php 13
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 24
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 25
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 26
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 27
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 28
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 29
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 31
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 32
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 33
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\admin\projects\index.php 34
ERROR - 2012-06-23 01:23:46 --> 404 Page Not Found --> invoices/5
ERROR - 2012-06-23 01:24:03 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:21 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:47 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:48 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:48 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:48 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:49 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:49 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:49 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:24:49 --> 404 Page Not Found --> projects/5
ERROR - 2012-06-23 01:25:26 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:25:30 --> 404 Page Not Found --> projects/15
ERROR - 2012-06-23 01:27:08 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:29:17 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:29:58 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:29:59 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:29:59 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:30:16 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:30:20 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:31:06 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:32:35 --> 404 Page Not Found --> projects/1
ERROR - 2012-06-23 01:32:39 --> 404 Page Not Found --> projects/TEST
ERROR - 2012-06-23 01:34:12 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:34:42 --> Query error: Unknown column 'success' in 'where clause'
ERROR - 2012-06-23 01:36:14 --> 404 Page Not Found --> invoices/6
ERROR - 2012-06-23 01:36:19 --> Severity: Notice  --> Undefined variable: invoice C:\wamp\www\client_manager\application\models\core.php 175
ERROR - 2012-06-23 01:36:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\invoices.php 49
ERROR - 2012-06-23 01:36:31 --> 404 Page Not Found --> projects/view
ERROR - 2012-06-23 01:38:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\projects.php 26
ERROR - 2012-06-23 01:38:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\tickets.php 47
ERROR - 2012-06-23 01:39:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\client\tickets.php 47
ERROR - 2012-06-23 01:39:18 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:22 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:23 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:23 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:24 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:24 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:24 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:40:24 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 16 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 17 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 18 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 19 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 20 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 21 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 22 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 23 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:25 --> Severity: Notice  --> Undefined offset: 24 C:\wamp\www\client_manager\application\views\admin\projects\index.php 23
ERROR - 2012-06-23 01:51:49 --> Severity: Notice  --> Undefined offset: 16 C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-23 01:51:49 --> Severity: Notice  --> Undefined offset: 17 C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-23 01:51:49 --> Severity: Notice  --> Undefined offset: 18 C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-23 01:51:49 --> Severity: Notice  --> Undefined offset: 19 C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-23 03:44:48 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-23 03:44:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-23 03:46:21 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-23 03:46:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-23 03:46:43 --> 404 Page Not Found --> projects/10
