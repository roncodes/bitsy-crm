<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-05 00:30:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-05 00:30:59 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-05 00:30:59 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:30:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-05 00:31:02 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:03 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:05 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:16 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:18 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:24 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:25 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:26 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:27 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:31 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:33 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:37 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 00:31:45 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 00:31:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:03:53 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-05 01:12:39 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-05 01:16:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:16:20 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-05 01:25:48 --> 404 Page Not Found --> projects
ERROR - 2012-06-05 01:25:56 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:25:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:26:06 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:26:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:26:16 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:26:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:27:04 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:27:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:33:30 --> Severity: Notice  --> Undefined property: stdClass::$fname C:\wamp\www\client_manager\application\controllers\admin\invoices.php 130
ERROR - 2012-06-05 01:33:30 --> Severity: Notice  --> Undefined property: stdClass::$lname C:\wamp\www\client_manager\application\controllers\admin\invoices.php 130
ERROR - 2012-06-05 01:33:30 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:33:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:35:51 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:35:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:38:14 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\admin\projects.php 120
ERROR - 2012-06-05 01:38:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:43:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:47:55 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 26
ERROR - 2012-06-05 01:47:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:49:47 --> 404 Page Not Found --> admin/ajax
ERROR - 2012-06-05 01:54:07 --> Severity: Notice  --> Undefined variable: display_head C:\wamp\www\client_manager\application\views\layouts\ajax.php 1
ERROR - 2012-06-05 01:56:26 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 27
ERROR - 2012-06-05 01:56:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 01:58:33 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 01:58:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:01:42 --> 404 Page Not Found --> ajax/get_client_projects
ERROR - 2012-06-05 02:01:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\ajax.php 41
ERROR - 2012-06-05 02:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\ajax.php 42
ERROR - 2012-06-05 02:05:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\ajax.php 42
ERROR - 2012-06-05 02:08:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\ajax.php 42
ERROR - 2012-06-05 02:10:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\ajax.php 43
ERROR - 2012-06-05 02:10:21 --> Severity: Notice  --> Undefined variable: project C:\wamp\www\client_manager\application\controllers\ajax.php 42
ERROR - 2012-06-05 02:10:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\controllers\ajax.php 42
ERROR - 2012-06-05 02:14:10 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:14:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:18:21 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:18:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:21:42 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:21:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:21:54 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:21:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:22:48 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:22:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:23:19 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:23:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:23:43 --> Severity: Warning  --> Missing argument 3 for bootstrap_dropdown(), called in C:\wamp\www\client_manager\application\views\admin\invoices\create.php on line 9 and defined C:\wamp\www\client_manager\application\helpers\site_helper.php 87
ERROR - 2012-06-05 02:23:43 --> Severity: Notice  --> Undefined variable: options C:\wamp\www\client_manager\application\helpers\site_helper.php 95
ERROR - 2012-06-05 02:23:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\client_manager\system\helpers\form_helper.php 331
ERROR - 2012-06-05 02:23:43 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:23:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:23:50 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:23:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:26:21 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:26:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:27:23 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:27:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:29:56 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:29:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:29:59 --> Severity: Notice  --> Undefined index: project_id C:\wamp\www\client_manager\application\controllers\ajax.php 28
ERROR - 2012-06-05 02:29:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:45:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 11
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Undefined property: stdClass::$invoice_id C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
ERROR - 2012-06-05 02:46:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\client_manager\application\views\frontend\index.php 12
