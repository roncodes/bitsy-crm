<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-26 02:51:00 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-26 02:51:59 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-26 02:52:12 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-26 03:46:34 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-26 03:47:36 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-26 03:48:55 --> 404 Page Not Found --> projects/10
ERROR - 2012-06-26 03:55:06 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-26 03:55:06 --> Severity: Notice  --> Undefined variable: row_start C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-26 03:55:06 --> Severity: Notice  --> Undefined variable: row_start C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-26 03:55:06 --> Severity: Notice  --> Undefined variable: per_page C:\wamp\www\client_manager\application\views\admin\projects\index.php 22
ERROR - 2012-06-26 03:55:06 --> Severity: Notice  --> Undefined variable: links C:\wamp\www\client_manager\application\views\admin\projects\index.php 45
ERROR - 2012-06-26 04:01:46 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:01:58 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:02 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:04 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:05 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:06 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:09 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:35 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:36 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:36 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:36 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:02:37 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:03:56 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:03:57 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:04:08 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:06:08 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\client_manager\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-06-26 04:06:12 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:06:16 --> 404 Page Not Found --> projects/$i
ERROR - 2012-06-26 04:16:45 --> 404 Page Not Found --> projects/admin
ERROR - 2012-06-26 04:17:48 --> 404 Page Not Found --> projects/page10
ERROR - 2012-06-26 04:23:54 --> Severity: Notice  --> Undefined variable: base_pagination C:\wamp\www\client_manager\application\helpers\site_helper.php 12
ERROR - 2012-06-26 04:23:54 --> Severity: Notice  --> Undefined variable: base_pagination C:\wamp\www\client_manager\application\helpers\site_helper.php 12
ERROR - 2012-06-26 04:46:46 --> Severity: Notice  --> Undefined variable: settings C:\wamp\www\client_manager\application\controllers\admin\options.php 20
