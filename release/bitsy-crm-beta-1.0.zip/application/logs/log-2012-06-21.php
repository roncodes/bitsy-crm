<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-06-21 00:00:01 --> 404 Page Not Found --> auth/admin
ERROR - 2012-06-21 19:39:38 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\client_manager\application\views\client\tickets\view.php 9
