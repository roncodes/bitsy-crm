<div class="footer">
	<div class="row-fluid">
		<div class="span4 foot-col">
			<ul class="nav nav-pills nav-stacked" style="width:200px;">
				<li><a href="">Terms Of Use</a></li>
				<li><a href="">Advertising</a></li>
				<li><a href="">Contact</a></li>
			</ul>
		</div>
		<div class="span4 foot-col">
			<img src="<?=base_url()?>public/img/milogo.png" width="100" height="100" style="text-align:center;margin-left:90px;">
		</div>
		<div class="span4 foot-col" style="border-right:0px;">
			<p>&copy <?php echo date('Y'); ?> Geo Site Framework. All Rights Reserved.</p>
			<p>Built from the ground up by Ronald A. Richardson</p>
		</div>
	</div>
</div>