<div class="fluff">
	<div class="alert alert-info"><?php echo $message; ?></div>
</div>