<!-- Test template | Ronald A. Richardson | 1.0 -->
<div class="welcome">
	<div class="row-fluid fluff">
		<div class="page-header" style="width:95%;">
			<h1><?php echo $title; ?> <small>this is a test template</small></h1>
		</div>
		<p><?php echo $content; ?></p>
	</div>
</div>