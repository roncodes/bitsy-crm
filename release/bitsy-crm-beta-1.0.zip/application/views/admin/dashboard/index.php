<div class="admin-panel">
<div class="page-header">
	<h1>Dashboard</h1>
</div>
<p class="lead">Welcome to the dashboard of your clients manager.</p>
<h3>Your income this month (<?=date('F')?>): <?=_money_format($monthly_income)?></h3>
</div>