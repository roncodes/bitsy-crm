<div class="panel">
	<div class="row-fluid fluff">
		<div class="span10">
			<div class="page-header">
				<h1>Admin <small>Dashboard</small></h1>
			</div>
			<p>
				<ul>
					<li>Your site has <?php echo $num_posts; ?> posts
					<li>Your site has <?php echo $num_pages; ?> pages
					<li>Your site has <?php echo $num_categories; ?> categories
					<li>Your site has <?php echo $num_templates; ?> page templates
				</ul>
			</p>
		</div>
	</div>
</div>