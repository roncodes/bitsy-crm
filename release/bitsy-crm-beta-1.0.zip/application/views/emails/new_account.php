<h1>Your New Acount Has Been Created</h1>
<p>Your new client account on <?=$system_name?> has just been created</p>
<p>You can login with the following credentials</p>
<blockquote>Login: <?=$login?><br>
Password: <?=$password?></blockquote><br>
<a href="<?=base_url()?>">Login Now!</a>