<h1><?=$user?> Has Made A Comment on the <?=$project_name?> Project</h1>
Check it out: <a href="<?=base_url()?>"><?=base_url()?></a>