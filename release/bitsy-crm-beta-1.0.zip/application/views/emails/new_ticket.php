<h1>New Ticket</h1>
<b><?=$username?></b> has posted a new ticket, (<?=$subject?>)<br>
<p>Check it out: <a href="<?=base_url('admin/tickets/view/'.$ticket_id)?>"><?=base_url('admin/tickets/view/'.$ticket_id)?></a></p>