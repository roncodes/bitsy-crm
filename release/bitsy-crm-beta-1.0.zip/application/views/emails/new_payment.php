<h1>New Payment!</h1>
<p><?=$user?> has just made a payment of <?=$payment_amount?> on invoice #<?=$invoice_id?></p>
Check it out: <a href="<?=base_url()?>"><?=base_url()?></a>