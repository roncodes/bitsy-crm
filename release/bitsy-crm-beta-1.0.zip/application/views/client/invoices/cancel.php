<div class="panel">
	<div class="page-header">
		<h1>Cancel Invoice Payment</h1>
	</div>
	<h3>You have opted to cancel payment</h3>
	<a href=".." class="btn">Click here to continue</a>
</div>